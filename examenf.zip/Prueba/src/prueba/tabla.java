package prueba;

public class tabla {

	public static void main(String[] args) {
		Scanner tc = new Scanner(System.in);
		int[][] arr = new int[10][3];
		int cont = 1;
		
		//Datos iniciales (columna1 cantidad, columna2 precio/unidad) 
for (int i = 0; i<arr.length; i++) {
for(int j = 0; j < 2; j++) {
				
System.out.println("Ingrese los datos del producto " + cont);
 arr[i][j] = tc.nextInt();
			}
			cont = cont + 1;
		}

for(int p = 0; p < arr.length; p++) {
	 int cantidad = arr[p][0];
	    int precioUnitario = arr[p][1];
	    int precioTotal = cantidad * precioUnitario;
	    arr[p][2] = precioTotal;
}
		
System.out.printf("| %-15s | %-12s | %-12s |\n", "Cantidad", "P/U", "Precio Total");	
System.out.println("----------------------------------------------------------------");
//Impresion de datos

for (int[] producto : arr) {
    System.out.printf("| %-15s | %-12s | %-12s |\n", producto[0], producto[1], producto[2]);
}
		
		tc.close();
		


	}

}
