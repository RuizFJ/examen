package prueba;

import java.util.Scanner;

public class examen2 {

	public static void main(String[] args) {
		
		Scanner tc = new Scanner(System.in);
		try {
		int array [];
		int n=7;
		array= new int [n];
int auxi,min=0;
		
	for (int i=0;i<n;i++) {
		System.out.println("Ingrese el numero "+i);
		array[i]=tc.nextInt();
	}
		
		
	
	for (int i=0;i<n;i++) {
		min = i;
		for (int j=i+1;j<n;j++) {
			if (array[j]<array[min]) {
				min=j;
			}
			auxi= array[min];
			array[min]=array[i];
			array[i]=auxi;
		}
	}
		
		System.out.println("Los numeros ordenados son");
	for (int i=0;i<n;i++) {
		System.out.print(array[i]+" ");
	}
		
		
		} catch (java.util.InputMismatchException m) {
			System.out.println("El dato debe de ser numerico");
		}
		
		
		
		
		
		
		
		
		
	}

}
