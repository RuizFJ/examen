package prueba;

import java.util.Scanner;

public class examen1 {

	public static void main(String[] args) {
		
		 Scanner tc = new Scanner(System.in);
	
		 String user = "usuario";
	        String password = "contraseña";
	        String name ,contra;
	        char opc;
	        int camisas,cantidad,suma;
	       
	        int count = 0;
	        do {
	       
	            System.out.println("Ingresa tu nombre de usuario:");
	             name = tc.nextLine();
	            System.out.println("Ingresa tu contraseña:");
	             contra = tc.nextLine();
count++;
	            if (name.equalsIgnoreCase(user) && contra.equalsIgnoreCase(password)) {
	                System.out.println("¡Bienvenido, " + user + "!");
	                
                    System.out.println("Ingrese una opciòn \na-Registrar datos \nb-Realizar tramite \nc-Imprimir factura \ne-Salir");
		opc=tc.next().charAt(0);
		
		switch (opc) {
		
		case 'a': System.out.println("Bienvenido");
		
		case 'b': System.out.println("Ha ingresado al sistema");
		do {
		System.out.println("Cuantas camisas desea comprar ");
		camisas=tc.nextInt();
		} while(camisas<=0);
		do {
		System.out.println("Ingrese el precio");
		cantidad=tc.nextInt();
		} while (cantidad<=0);
		suma= camisas*cantidad;
		System.out.println("Su compra sale por "+suma);
		break;
		
		case 'c': 
			System.out.println("Para imprimir factura se necesitan 2 datos= cantidad y precio");
			do {
		System.out.println("Ingrese la cantidad de camisas");
		camisas=tc.nextInt();
			} while (camisas<=0);
			do {
		System.out.println("Ingrese el precio el cual las comprò");
		cantidad=tc.nextInt();
			} while (cantidad<=0);
		suma= camisas*cantidad;
		System.out.println("Cantidad de camisas = "+camisas+"\nPrecio = "+cantidad+"\nTotal a pagar "+suma);
		break;
		
		case 'e': System.out.println("Saliendo");
		break;
		
		default: System.out.println("Opcion invalida");
		break;
		
		}
		
	                
	                if (opc=='e') {
	                	System.out.println("Ha decidido salir del programa");
	                }
	            }	
	                }  while ( count< 3 && !name.equalsIgnoreCase(user) && !contra.equalsIgnoreCase(password));
	             if (count==3) {
                	System.out.println("Intentos agotados");	
		
	        }
		
	}
		
}
		

		

	        	
		
	


