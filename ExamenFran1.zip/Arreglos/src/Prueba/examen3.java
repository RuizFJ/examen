package Prueba;

public class examen3 {

	public static void main(String[] args) {
		
		
		int n=6,f=0,g,h=1;
		
		for (int i=1;i<=n;i++) {
			g=f;
			f=f+h;
			h=g;
			System.out.println(h);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
