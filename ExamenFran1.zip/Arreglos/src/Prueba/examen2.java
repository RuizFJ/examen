package Prueba;

import java.util.Scanner;

public class examen2 {

	public static void main(String[] args) {
		Scanner tc = new Scanner(System.in);
		try {
		int array [];
		int n=7;
		array= new int [n];
int auxi=0,min=0;
		
	for (int i=0;i<n;i++) {
		System.out.println("Ingrese el numero "+i);
		array[i]=tc.nextInt();
	}
		
		
	
	for (int i=0;i<n-1;i++) {
		min = i;
		for (int j=i+1;j<n;j++) {
			if (array[j]<array[min]) {
				min=j;
			}
			auxi= array[i];
			array[i]=array[min];
			array[min]=auxi;
		}
	}
		
		System.out.println("Los numeros ordenados son");
	for (int k=0;k<n;k++) {
		System.out.print(array[k]+" ");
	}
		
		
		} catch (java.util.InputMismatchException m) {
			System.out.println("El dato debe de ser numerico");
		}
		
		
		

	}

}
